# 💰 Ftop Money - Boshqotirma O'yinlar Sayti

Professional boshqotirma o'yinlari bilan pul ishlash platformasi.

## 🎮 O'yinlar

1. **Farqlarni Top** - 10 ta farqni topib, ball yig'ing
2. **Bomba O'yini** - Xavfli bombalardan qoching
3. **Baraban O'yini** - Omadingizni sinab ko'ring

## 🚀 Saytni ishga tushirish

### GitHub Pages orqali (BEPUL)

1. Ushbu repository'ni fork qiling
2. Settings → Pages ga o'ting
3. Source: "Deploy from a branch" tanlang
4. Branch: "main" va "/root" tanlang
5. Save bosing

2-3 daqiqada saytingiz tayyor: `https://sizning-username.github.io/ftop-money`

### Netlify orqali (BEPUL)

1. https://www.netlify.com ga o'ting
2. "Add new site" → "Import an existing project"
3. GitHub bilan bog'lang
4. Repository'ni tanlang
5. Deploy bosing

Natija: `https://sizning-nom.netlify.app`

## 💰 Google AdSense qo'shish

1. https://www.google.com/adsense da hisobni yarating
2. Sayt URL'ini kiriting (GitHub/Netlify bergan URL)
3. Reklama kodini oling
4. `index.html` faylidagi `<div class="ad-space">` joylariga joylashtiring

## 📊 Daromad

- 1000 ko'rish/kun → 50,000-100,000 so'm/oy
- 5000 ko'rish/kun → 250,000-500,000 so'm/oy
- 10,000 ko'rish/kun → 500,000-1,000,000 so'm/oy

## 📞 Qo'llab-quvvatlash

Savollar bo'lsa, issue yarating yoki bog'laning.

---

**Muhim:** Bu sayt faqat o'yin-kulgi va reklama orqali daromad olish uchun. Hech qanday qimor yoki pul tikish elementi yo'q - 100% qonuniy platform.
