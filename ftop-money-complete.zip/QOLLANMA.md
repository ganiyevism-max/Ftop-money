# 🎯 SAYTNI INTERNETGA CHIQARISH - QADAMMA-QADAM QO'LLANMA

## ⚡ ENG OSON USUL: GitHub Pages (5 daqiqa)

### 1-QADAM: GitHub hisobi yaratish
1. https://github.com ga o'ting
2. "Sign Up" tugmasini bosing
3. Email, parol kiriting
4. Hisobni tasdiqlang

### 2-QADAM: Yangi Repository yaratish
1. GitHub'da login qiling
2. O'ng yuqoridagi "+" belgisini bosing
3. "New repository" tanlang
4. Repository nomi: `ftop-money` (yoki istalgan nom)
5. "Public" tanlang (muhim!)
6. "Create repository" bosing

### 3-QADAM: Fayllarni yuklash
1. Repository ochilgandan keyin "uploading an existing file" havolasini bosing
2. `index.html` faylini tortib tashlang (ftop-money.html ni oldin index.html deb nomlang)
3. "Commit changes" bosing

### 4-QADAM: GitHub Pages yoqish
1. Repository'da "Settings" ga o'ting
2. Chap paneldan "Pages" ni tanlang
3. "Source" ostida "Deploy from a branch" tanlang
4. "Branch" da "main" va "/root" tanlang
5. "Save" bosing

### 5-QADAM: Saytingiz tayyor! 🎉
2-3 daqiqadan keyin saytingiz ishlaydi:
```
https://sizning-username.github.io/ftop-money
```

---

## 🚀 IKKINCHI USUL: Netlify (Yanada Oson!)

### 1-QADAM: Netlify hisobi
1. https://www.netlify.com ga o'ting
2. "Sign Up" bosing
3. GitHub orqali kiring (yoki email bilan)

### 2-QADAM: Saytni yuklash
1. "Add new site" tugmasini bosing
2. "Deploy manually" tanlang
3. `index.html` faylini tortib tashlang
4. 10 sekund kutasiz

### 3-QADAM: Tayyor!
Netlify sizga URL beradi:
```
https://random-name-123.netlify.app
```

**Bonus:** Netlify'da "Domain settings" ga o'tib, nomni o'zgartirishingiz mumkin:
```
https://ftop-money.netlify.app
```

---

## 💰 GOOGLE ADSENSE QO'SHISH

### 1-QADAM: AdSense hisobi yaratish
1. https://www.google.com/adsense ga o'ting
2. "Get Started" bosing
3. Gmail hisobingiz bilan kiring
4. Sayt URL'ini kiriting (GitHub yoki Netlify bergan URL)
5. Ma'lumotlaringizni to'ldiring

### 2-QADAM: Tasdiqlashni kutish
- Google saytingizni tekshiradi (1-2 kun)
- Email orqali xabar keladi

### 3-QADAM: Reklama kodini olish
1. AdSense paneliga kiring
2. "Ads" → "Overview" ga o'ting
3. "By ad unit" → "Display ads" tanlang
4. Reklama o'lchamini tanlang
5. "Get code" tugmasini bosing

### 4-QADAM: Kodni saytga qo'shish
1. `index.html` faylini oching
2. `<div class="ad-space">` ni toping (2 ta bor)
3. Ichidagi matnni o'chirib, AdSense kodini joylashtiring
4. Faylni saqlang va qayta yuklang

---

## 📱 SAYTNI MASHHUR QILISH

### Ijtimoiy tarmoqlarda
- Telegram kanallar va guruhlarda ulashing
- Instagram, Facebook'da e'lon bering
- TikTok'da video roliklar yarating

### SEO (Qidiruv tizimlarida chiqish)
- Google Search Console'ga qo'shing
- Saytga yangi o'yinlar qo'shing
- Muntazam yangilanishlar qiling

---

## ❓ TEZ-TEZ SO'RALADIGAN SAVOLLAR

**S: Sayt ishlamayapti, nima qilish kerak?**
J: GitHub Pages'da "Settings" → "Pages" → URL'ni tekshiring. 2-3 daqiqa kutish kerak.

**S: AdSense tasdiqlamayapti?**
J: Saytingizda kamida 20-30 ta sahifa bo'lishi kerak. Ko'proq o'yinlar va sahifalar qo'shing.

**S: Qancha daromad olaman?**
J: 1000 tashrif/kun ≈ 50,000-100,000 so'm/oy. Ko'proq tashrif = ko'proq pul.

**S: Hosting uchun pul to'lash kerakmi?**
J: YO'Q! GitHub Pages va Netlify 100% BEPUL.

---

## 🎉 TAYYOR!

Endi sizda:
✅ Professional sayt
✅ Bepul hosting
✅ URL manzil
✅ AdSense uchun tayyor platforma

**Keyingi qadam:** AdSense'ga ariza bering va pul ishlashni boshlang! 💰
